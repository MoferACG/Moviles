import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:untitled/agradecimiento.dart';


class addComanda extends StatefulWidget {
  addComanda({Key? key, required this.orden, required this.precios}) : super(key: key);
  List<String> orden;
  List<int> precios;

  @override
  State<addComanda> createState() => _addComandaState();
}

class _addComandaState extends State<addComanda> {
  @override
  Widget build(BuildContext context) {

    return Material(
      child: Container(
        alignment: Alignment.center,
        child:
      TextButton(
        onPressed: (){
          print("->Guardando la orden..." + widget.orden.toString());
          CollectionReference ordendb = FirebaseFirestore.instance.collection('comanda');
          final now = DateTime.now();
          final FirebaseAuth firebaseAuth = FirebaseAuth.instance;
          ordendb.add({
            'user' : firebaseAuth.currentUser?.email,
            'diahora' : now,
            'orden': {
              'description':widget.orden.toList(),
              'cantidad':widget.orden.length,
              'subtotal':widget.precios.toList()
            },
            'total': widget.precios.fold(0, (previous, current) => previous + current)
          }).then((value) => print("Comanda Agregada"))
              .catchError((error) => print("Fallo al intentar agregar la comanda: $error"));
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => agradecimientos()
              )
          );
        },
        child: Text('Guardar orden',),

      ),
      )
    );
  }
}