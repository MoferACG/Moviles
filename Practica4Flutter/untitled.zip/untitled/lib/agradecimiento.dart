import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class agradecimientos extends StatelessWidget{
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Text("Pizza de Don Cangrejo"),),
      body: Center(child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Column(mainAxisAlignment: MainAxisAlignment.center,
            children:
          [Row(
              children:[
                Text(
                    "Gracias por su preferencia \n"
                ),
              ]),
            Row(
                children:[
                  MaterialButton(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(
                            Radius.circular(34.0)
                        ),
                      ),
                      padding: EdgeInsets.all(20),
                      elevation: 10.0,
                      color: Colors.white,
                      child: Text(
                          'Volver'
                      ),
                      onPressed: (){
                        Navigator.pop(context);
                      }
                  ),
                ])],)

        ],
      ),)

    );
  }
}