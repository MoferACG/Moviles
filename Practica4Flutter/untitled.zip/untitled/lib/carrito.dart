import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'ComandaDB_ui.dart';

class carrito extends StatefulWidget {
  carrito({Key? key, required this.orden, required this.precios}) : super(key: key);
  List<String> orden;
  List<int> precios;

  @override
  State<carrito> createState() => ProductList();
}

class ProductList extends State<carrito> {
  double total = 0.0;

  void precio_total() {
    total = widget.precios.fold(0, (previous, current) => previous + current);
  }

  @override
  void initState() {
    super.initState();
    precio_total();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Orden'),
      ),
      body: ListView.builder(
        itemCount: widget.orden.length,
        itemBuilder: (BuildContext context, int index) {
          final product = widget.orden[index].split(' - ');
          final name = product[0];
          final precios = widget.precios;
          final precio = precios[0];
          total = widget.precios.fold(0, (previous, current) => previous + current);
          // final price
          return ListTile(
            title: Text(name),
            subtitle: Text(precios[index].toString()),
          );
        },

      ),
      bottomNavigationBar: BottomAppBar(
        child: Container(
          height: 50.0,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Padding(
                padding: EdgeInsets.only(left: 10.0),
                child: Text(
                  'Total: \$${total.toStringAsFixed(2)}',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20.0,
                  ),
                ),
              ),
              Row(
                children: [
                  addComanda(orden: widget.orden, precios: widget.precios,)

                ],
              ),
            ],
          ),
        ),
      ),

    );
  }
}

