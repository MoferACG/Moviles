import 'package:firebase_auth/firebase_auth.dart'
hide EmailAuthProvider, PhoneAuthProvider;  // new
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:untitled/Authentication.dart';
import 'package:untitled/agradecimiento.dart';
import 'package:untitled/carrito.dart';
import 'app_state.dart';
import 'ComandaDB_ui.dart';
import 'package:provider/provider.dart'; //nuevo
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';



class DashboardScreen extends StatefulWidget {
  DashboardScreen({Key? key, required this.loggedIn, required this.signOut}): super(key: key);
  final bool loggedIn;
  final void Function() signOut;
  final List<String> _orden = List.empty(growable: true);
  final List<int> _precios = List.empty(growable: true);
  final List<String> orden = List.empty(growable: true);
  int cantidad = 0;

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}



class _DashboardScreenState extends State<DashboardScreen> {
  void _cambio() {
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => carrito(orden: widget._orden, precios: widget._precios))
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widget.loggedIn) {
      return Scaffold(
          appBar: AppBar(
            title: Text("Nostra Pizza"),
          ),
          body: Column(
              children: [
                Row(
                  children: [

                    PizzaImage(image: 'asd.jpg', item: 'Pizza de Pepperoni', precio: 150,orden: widget._orden, precios: widget._precios, cantidad: 1,),
                    Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 50.0),
                          child: Container(
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Column(
                                children: [
                                  Text('Pizza de peperoni',
                                      style: TextStyle(fontFamily: 'Roboto', fontSize: 24)),
                                  Text('Pizza de masa madre queso y peperoni',
                                      style: TextStyle(fontFamily: 'Roboto', fontSize: 16)),
                                  Text('150',
                                      style: TextStyle(fontFamily: 'Roboto', fontSize: 16)),

                                ],
                              ),
                            ),
                          ),
                        )
                      ],
                    )
                  ],
                ),
                Row(
                  children: [
                    PizzaImage(image: 'queso.jpg', item: 'Pizza de Queso', precio: 200,orden: widget._orden , precios: widget._precios, cantidad: 1,),

                    Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 50.0),
                          child: Container(
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Column(
                                children: [
                                  Text('Pizza de queso',
                                      style: TextStyle(fontFamily: 'Roboto', fontSize: 24)),
                                  Text('Pizza de masa madre con 4 quesos y finas hierbas',
                                      style: TextStyle(fontFamily: 'Roboto', fontSize: 16)),
                                  Text('200',
                                      style: TextStyle(fontFamily: 'Roboto', fontSize: 16)),

                                ],
                              ),
                            ),
                          ),
                        )
                      ],
                    )
                  ],
                ),
                Row(
                  children: [
                    PizzaImage(image: 'swewe.jpg', item: 'Pizza de Aceitunas', precio: 300 ,orden: widget._orden, precios: widget._precios, cantidad: 1,),

                    Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 50.0),
                          child: Container(
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Column(
                                children: [
                                  Text('Pizza de aceitunas',
                                      style: TextStyle(fontFamily: 'Roboto', fontSize: 24)),
                                  Text('Pizza de masa madre y aceitunas',
                                      style: TextStyle(fontFamily: 'Roboto', fontSize: 16)),
                                  Text('300',
                                      style: TextStyle(fontFamily: 'Roboto', fontSize: 16)),

                                ],
                              ),
                            ),
                          ),
                        )
                      ],
                    )
                  ],
                ),

                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 24, bottom: 8),
                      child: MaterialButton(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(
                                Radius.circular(34.0)
                            ),
                          ),
                          padding: EdgeInsets.all(20),
                          elevation: 10.0,
                          color: Colors.white,
                          child: Text(
                              'Cerrar sesion'
                          ),
                          onPressed: (){
                            widget.signOut();
                          }
                      ),
                    ),
                  ],
                )
              ]
          ),
          floatingActionButton: Stack(
            children: [
              FloatingActionButton(
                onPressed: _cambio,
                child: Icon(Icons.shopping_cart),
              ),
              Positioned(
                top: 0,
                right: 0,
                child: Container(
                  padding: EdgeInsets.all(4),

                ),
              ),
            ],
          )



      );
    } else {
      return Authentication();
    }
  }
}

class PizzaImage extends StatefulWidget {
  PizzaImage({Key? key, required this.image, required this.item, required this.precio, required this.orden, required this.precios, required this.cantidad}) : super(key: key);
  final String image;
  final String item;
  final int precio;
  List<String> orden;
  List<int> precios;
  final int cantidad;


  @override
  State<PizzaImage> createState() => _PizzaImageState();

}

class _PizzaImageState extends State<PizzaImage>{
  @override
  Widget build(BuildContext context){
    return Material(
        child: GestureDetector(

          onTap: () {
            final snackBar = SnackBar(
              content: Text("Haz ordenado a la orden " + widget.item),
            );
            ScaffoldMessenger.of(context).showSnackBar(snackBar);
            widget.orden.add(widget.item);
            widget.precios.add(widget.precio);
            print("\norden: \n");
            print(widget.orden);
            print(widget.precios);

          },
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Image.asset(widget.image, width: 150, height: 100,),
                  ],
                ),)
            ],
          ),
        )
    );
  }
}
